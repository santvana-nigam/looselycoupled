package com.hsbc.wsit.hackathon;

import java.io.IOException;

public class PipelineMain {
	public static void main(String[] args) throws IOException {
		ApachePoiPieChart.pieChartStatusOverview();
		ApachePoiPieChart.pieChartFailure();
		ImageToPPT.ImageToPPT();
		System.out.println("OKAY");
	}

}
