package com.hsbc.wsit.hackathon;

import java.awt.Rectangle;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.hslf.usermodel.HSLFPictureData;
import org.apache.poi.hslf.usermodel.HSLFPictureShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hslf.usermodel.HSLFTextBox;
import org.apache.poi.sl.usermodel.TextBox;
import org.apache.poi.util.IOUtils;

public class ImageToPPT {

	public static void ImageToPPT() throws IOException {

		// creating a presentation
		
		FileOutputStream fileOutputStream = new FileOutputStream(new File("Chart.ppt"));
		// create a new slide show
		HSLFSlideShow hslfSlideShow = new HSLFSlideShow();
		// create slide
		HSLFSlide slide = hslfSlideShow.createSlide();
		// load image
		HashMap<String, Integer> hmap = new ReadFromExcel().getData();
		HSLFTextBox txtBox = new HSLFTextBox();
		txtBox.setText("Total No. of Deployements: " + hmap.get("Total No. of deployements").toString()
				+ "\n"+"No. of G3 deploys: " + hmap.get("No. of G3 deploys ").toString() + "\n" + "No. of Ansible deploys: "
				+ hmap.get("No. of Ansible deploys").toString());
		txtBox.setAnchor(new java.awt.Rectangle(200, 100, 300, 50));
		slide.addShape(txtBox);
		
		byte[] picture = IOUtils.toByteArray(new FileInputStream(new File("status_0.png")));
		// add image
		HSLFPictureData hslfPictureData = hslfSlideShow.addPicture(picture, HSLFPictureData.PictureType.PNG);
		HSLFPictureShape pictureShape = slide.createPicture(hslfPictureData);
		pictureShape.setAnchor(new Rectangle(50, 250, 300, 225));
		// save file
		picture = IOUtils.toByteArray(new FileInputStream(new File("failure_0.png")));
		// add image
		hslfPictureData = hslfSlideShow.addPicture(picture, HSLFPictureData.PictureType.PNG);
		pictureShape = slide.createPicture(hslfPictureData);
		pictureShape.setAnchor(new Rectangle(375, 250, 300, 225));
		hslfSlideShow.write(fileOutputStream);
		// close stream	

		fileOutputStream.close();
		//System.out.println("chla");
	}
}
