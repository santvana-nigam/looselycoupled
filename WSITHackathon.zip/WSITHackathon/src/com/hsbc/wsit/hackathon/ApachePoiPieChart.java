package com.hsbc.wsit.hackathon;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xddf.usermodel.chart.ChartTypes;
import org.apache.poi.xddf.usermodel.chart.LegendPosition;
import org.apache.poi.xddf.usermodel.chart.XDDFChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFChartLegend;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSourcesFactory;
import org.apache.poi.xddf.usermodel.chart.XDDFNumericalDataSource;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.aspose.cells.Chart;
import com.aspose.cells.ImageFormat;
import com.aspose.cells.ImageOrPrintOptions;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;

public class ApachePoiPieChart {

	

	public static void pieChartStatusOverview() throws FileNotFoundException, IOException {
		
		HashMap<String, Integer> hmap=new ReadFromExcel().getData();
		try (XSSFWorkbook wb = new XSSFWorkbook()) {

			XSSFSheet sheet = wb.createSheet("status");

			// Create row and put some cells in it. Rows and cells are 0 based.
			Row row = sheet.createRow((int) 0);

			Cell cell = row.createCell((int) 0);
			cell.setCellValue("Success");

			cell = row.createCell((int) 1);
			cell.setCellValue("Failure");

			cell = row.createCell((int) 2);
			cell.setCellValue("Unstable");

			cell = row.createCell((int) 3);
			cell.setCellValue("Rollback");

//			cell = row.createCell((short) 4);
//			cell.setCellValue("Brazil");
//
//			cell = row.createCell((short) 5);
//			cell.setCellValue("Australia");
//
//			cell = row.createCell((short) 6);
//			cell.setCellValue("India");

			row = sheet.createRow((int) 1);

			cell = row.createCell((int) 0);
			cell.setCellValue(hmap.get("No. of success"));

			cell = row.createCell((int) 1);
			cell.setCellValue(hmap.get("No. of Failure"));

			cell = row.createCell((int) 2);
			cell.setCellValue(hmap.get("No. of unstable"));

			cell = row.createCell((int) 3);
			cell.setCellValue(hmap.get("No. of Rollback"));

//			cell = row.createCell((short) 4);
//			cell.setCellValue(8514877);
//
//			cell = row.createCell((short) 5);
//			cell.setCellValue(7741220);
//
//			cell = row.createCell((short) 6);
//			cell.setCellValue(3287263);

			XSSFDrawing drawing = sheet.createDrawingPatriarch();
			XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 4, 7, 20);

			XSSFChart chart = drawing.createChart(anchor);
			chart.setTitleText("Status Overview");
			chart.setTitleOverlay(false);

			XDDFChartLegend legend = chart.getOrAddLegend();
			legend.setPosition(LegendPosition.TOP_RIGHT);

			XDDFDataSource<String> countries = XDDFDataSourcesFactory.fromStringCellRange(sheet,
					new CellRangeAddress(0, 0, 0, 3));

			XDDFNumericalDataSource<Double> values = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
					new CellRangeAddress(1, 1, 0, 3));

			XDDFChartData data = chart.createData(ChartTypes.PIE3D, null, null);// chart.createData(ChartTypes.PIE,
																				// null, null);
			data.setVaryColors(true);
			data.addSeries(countries, values);
			chart.plot(data);

			// Write output to an excel file
			try (FileOutputStream fileOut = new FileOutputStream("statusoverview.xlsx")) {
				wb.write(fileOut);
				try {
					MethodToExtractCharts("statusoverview.xlsx","status");
					System.out.println("WORK");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
public static void pieChartFailure() throws FileNotFoundException, IOException {
		
		HashMap<String, Integer> hmap=new ReadFromExcel().getData();
		try (XSSFWorkbook wb = new XSSFWorkbook()) {

			XSSFSheet sheet = wb.createSheet("failure");

			// Create row and put some cells in it. Rows and cells are 0 based.
			Row row = sheet.createRow((int) 0);

			Cell cell = row.createCell((int) 0);
			cell.setCellValue("Production Bugs");

			cell = row.createCell((int) 1);
			cell.setCellValue("Incorrect/Outdated Credentials");

			cell = row.createCell((int) 2);
			cell.setCellValue("Network Issues");

//			cell = row.createCell((int) 3);
//			cell.setCellValue("Rollback");

//			cell = row.createCell((short) 4);
//			cell.setCellValue("Brazil");
//
//			cell = row.createCell((short) 5);
//			cell.setCellValue("Australia");
//
//			cell = row.createCell((short) 6);
//			cell.setCellValue("India");

			row = sheet.createRow((int) 1);

			cell = row.createCell((int) 0);
			cell.setCellValue(hmap.get("Production bugs"));

			cell = row.createCell((int) 1);
			cell.setCellValue(hmap.get("Incorrect/outdated credentials"));

			cell = row.createCell((int) 2);
			cell.setCellValue(hmap.get("Network Issue"));

//			cell = row.createCell((int) 3);
//			cell.setCellValue(hmap.get("No. of Rollback"));

//			cell = row.createCell((short) 4);
//			cell.setCellValue(8514877);
//
//			cell = row.createCell((short) 5);
//			cell.setCellValue(7741220);
//
//			cell = row.createCell((short) 6);
//			cell.setCellValue(3287263);

			XSSFDrawing drawing = sheet.createDrawingPatriarch();
			XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 4, 7, 20);

			XSSFChart chart = drawing.createChart(anchor);
			chart.setTitleText("Reasons Of Failure");
			chart.setTitleOverlay(false);

			XDDFChartLegend legend = chart.getOrAddLegend();
			legend.setPosition(LegendPosition.TOP_RIGHT);

			XDDFDataSource<String> countries = XDDFDataSourcesFactory.fromStringCellRange(sheet,
					new CellRangeAddress(0, 0, 0, 2));

			XDDFNumericalDataSource<Double> values = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
					new CellRangeAddress(1, 1, 0, 2));

			XDDFChartData data = chart.createData(ChartTypes.PIE3D, null, null);// chart.createData(ChartTypes.PIE,
																				// null, null);
			data.setVaryColors(true);
			data.addSeries(countries, values);
			chart.plot(data);

			// Write output to an excel file
			try (FileOutputStream fileOut = new FileOutputStream("failure.xlsx")) {
				wb.write(fileOut);
				try {
					MethodToExtractCharts("failure.xlsx","failure");
					System.out.println("WORK");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	private static void MethodToExtractCharts(String file,String sheetName) throws Exception 
	{
		FileInputStream fis=new FileInputStream(new File(file));
		Workbook wb=new Workbook(fis);
		Worksheet sheet=wb.getWorksheets().get(sheetName);
		
		if(sheet!=null)
		{
			for(int i=0;i<sheet.getCharts().getCount();i++)
			{
				Chart ch=sheet.getCharts().get(i);
				
				if(ch!=null)
				{
					ImageOrPrintOptions opts = new ImageOrPrintOptions();
					opts.setImageFormat(ImageFormat.getPng());
					
					
					
					ch.toImage(sheet.getName()+"_"+i+".png",opts);
				}
			}
		}
	}

}