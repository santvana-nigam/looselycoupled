package com.hsbc.wsit.hackathon;

import java.io.File;
import java.util.HashMap;

import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;



public class ReadFromExcel {
	
	public HashMap<String, Integer> getData() {
		
		//File inFile=new File("C:\\Users\\Sukriti Shukla\\Desktop\\dataset.xlsx");
		HashMap<String, Integer> hmap=new HashMap<String, Integer>();
		//XSSFWorkbook workbook = new Workbook(inFile);
		try {
			Workbook workbook= new Workbook("dataset.xlsx");
			 WorksheetCollection worksheets=workbook.getWorksheets();
			 Worksheet worksheet=worksheets.get(0);
			 
			 for(int i=0;i<=worksheet.getCells().getMaxDataRow();i++)
			 {
				 hmap.put(worksheet.getCells().get(i, 0).getStringValue(),worksheet.getCells().get(i, 2).getIntValue() );
			 }
			 
			// System.out.println(hmap);
			 
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			return hmap;	
	}
	public static void main(String[] args) {
		new ReadFromExcel().getData();
	}
}
